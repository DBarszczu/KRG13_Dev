package com.rg.krg13_dev.autocomputer

data class Data(
    var reportFrame: String = "" // tu możesz odkładać ramkę po skasowaniu biletu
)
